package edu.mit.media.hd.hellodata;

import android.app.Activity;
import android.webkit.WebView;

class JavaScriptInterface{
	public static WebView webview;
	public static Activity activity;
	public void showHTML(String html){

	String substring = "MITDavosABC";
	boolean found=false;
	found=html.contains(substring);

	if(found){
		System.out.println("Keyword is found");
		WebViewUtil.SaveWebView(webview,  activity);
	}
	else{
		System.out.println("Keyword not found");

	}
	}
}
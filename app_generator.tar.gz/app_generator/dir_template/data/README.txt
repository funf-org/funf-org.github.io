Raw data directly from devices is stored in the raw directory.  To put all of this data in one db file run merge_data in the scripts directory.

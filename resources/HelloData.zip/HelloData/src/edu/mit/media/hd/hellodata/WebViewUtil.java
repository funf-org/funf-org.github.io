package edu.mit.media.hd.hellodata;

import java.io.File;
import java.io.FileOutputStream;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Picture;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

// Save and restore webview states
// author: Wei Pan	
public class WebViewUtil {
	public static final String TAG ="funf_webviewutil";
	public static boolean SaveWebView(WebView wv, Context context) {
		
		if (savelock == true)
			return false;
		boolean re = true;
		Picture pic = wv.capturePicture();
		if ((pic.getWidth() < 1) || (pic.getHeight() < 1))
				return false;
		Bitmap bb = Bitmap.createBitmap(pic.getWidth(), pic.getHeight(), Bitmap.Config.ARGB_8888);
		Canvas canvas = new Canvas(bb);
		pic.draw(canvas);
		try {
			FileOutputStream fos = new FileOutputStream(context.getDatabasePath("wvpic") + ".png");
			bb.compress(Bitmap.CompressFormat.PNG, 100, fos);
			fos.close();
			Log.i(TAG, "save webview state "  + re);
		} catch (Exception ee) {Log.e(TAG, "error, cannot save instance!"); ee.printStackTrace();}
		
		Log.i(TAG, "save webview state "  + re);
		return re;
	}
	public static boolean savelock = false;
	public static boolean loadWebView(WebView wv,  Context context) {
		
		savelock = true;
		Toast.makeText(context, "Local cached version ", Toast.LENGTH_SHORT).show();
		File f = new File(context.getDatabasePath("wvpic") + ".png");
		if (!f.exists())
			return false;
		wv.loadUrl("file://" + context.getDatabasePath("wvpic") + ".png");
		return true;
	}
}

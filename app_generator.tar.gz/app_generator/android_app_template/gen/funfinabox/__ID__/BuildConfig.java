/** Automatically generated file. DO NOT MODIFY */
package funfinabox.__ID__;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
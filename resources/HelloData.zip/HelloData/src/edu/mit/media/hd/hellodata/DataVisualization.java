package edu.mit.media.hd.hellodata;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.NoSuchAlgorithmException;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Picture;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.Toast;


public class DataVisualization extends Activity {
		public static final String TAG = "funf_" + DataVisualization.class.getCanonicalName();
		
		private static String VIS_URL = "https://www.trustframeworkmanager.com/GoogleIO/";
		
		private WebView webview;
		private TextView loadingText;
		
		@Override
		protected void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			setContentView(R.layout.datavisualization);

			

	        // For WEF project, Webview
	        webview = (WebView)findViewById(R.id.webview);
	        webview.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
	        webview.getSettings().setJavaScriptEnabled(true);
	        webview.getSettings().setSupportZoom(false);/* Register a new JavaScript interface called HTMLOUT */  
	        webview.addJavascriptInterface(new JavaScriptInterface(), "HTMLOUT");  
	        
	        final DataVisualization activity = this;
	        loadingText = (TextView) findViewById(R.id.loadingText);
	        
	        webview.setWebChromeClient(new WebChromeClient() {
	          public void onProgressChanged(WebView view, int progress) {
	            // Activities and WebViews measure progress with different scales.
	            // The progress meter will automatically disappear when we reach 100%
	        	  activity.setProgress(progress * 1000);

	          }
	        });
	        
	         
	        webview.setPictureListener(new WebView.PictureListener() {
				
				@Override
				public void onNewPicture(WebView view, Picture picture) {
					
					
				}
			});
	        webview.setWebViewClient(new WebViewClient() {
	        	@Override
	        	public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
	        		Toast.makeText(activity, "No internet connection " + description, Toast.LENGTH_SHORT).show();
	        		try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
					}
	        		
	        	    WebViewUtil.loadWebView(webview, activity);
	        	}
	        	@Override
	        	public void onPageFinished(WebView view, String url) {
	        		//loadingText.setVisibility(View.INVISIBLE);
	        		WebViewUtil.savelock = false;
	        		ConnectivityManager cm = (ConnectivityManager) activity.getSystemService(Activity.CONNECTIVITY_SERVICE);
				    // Log.i(TAG, "+" + view.getContentHeight());
	 				if ((null != cm.getActiveNetworkInfo()) && (cm.getActiveNetworkInfo().isConnected())) {
	 			        JavaScriptInterface.activity = activity;
	 			        JavaScriptInterface.webview = view;
	 					webview.loadUrl("javascript:window.HTMLOUT.showHTML('<head>'+document.getElementsByTagName('html')[0].innerHTML+'</head>');");  
	 					// WebViewUtil.SaveWebView(view,  self);
	 				
	 				}
	 				loadingText.setVisibility(View.GONE);
	 				webview.setVisibility(View.VISIBLE);
	        	}
	        });
	        
	        byte[] postdata = loadPDSandToken();
	        if (postdata == null) {
	        	Log.e(TAG, "pds data not available");
	            new AlertDialog.Builder(this)
	            .setMessage("Your access token is not present. Please make sure your Digital Wallet is working properly.")
	            .show();
	        } else {
	        	ConnectivityManager cm = (ConnectivityManager) this.getSystemService(Activity.CONNECTIVITY_SERVICE);
	        	if ((null == cm.getActiveNetworkInfo()) || (!cm.getActiveNetworkInfo().isConnected()))
	        		WebViewUtil.loadWebView(webview,  this);
	        	else
	        		webview.postUrl(VIS_URL, postdata);
	        		//webview.loadUrl("www.google.com");
	        }
		}

		@Override
		protected void onResume() {
			super.onResume();
			if (loadingText.getVisibility() == View.INVISIBLE) {
	    		loadingText.setVisibility(View.VISIBLE);
	    		webview.reload();
	    	}
		}
		
		//private static final int MENU_ADMIN = 0;
	    //private static final int MENU_ABOUT = 1;
	    //private static final int MENU_SYNC = 2;
	    //private static final int MENU_UPDATE = 3;
	    //private static final int MENU_CACHE = 7;
	    private static final int MENU_REFRESH = 4;
	    //private static final int MENU_AUTH = 5;
	    //private static final int MENU_MORE = 6;

		@Override
	    public boolean onCreateOptionsMenu(Menu menu) {
	    	MenuItem m;
	    	//m = menu.add(0, MENU_AUTH, 2, "Authorization");
	    	//m.setIcon(R.drawable.ic_menu_account_list);
	    	m = menu.add(0, MENU_REFRESH, 1, "Refresh");
	    	m.setIcon(R.drawable.ic_menu_refresh);
	    	//m = menu.add(0, MENU_CACHE, 2, "Cached");
	    	//m.setIcon(android.R.drawable.ic_menu_agenda);
	    	//SubMenu mm = menu.addSubMenu(0, MENU_MORE, 3, "More");
	    	//mm.setIcon(android.R.drawable.ic_menu_more);
	    	//m = mm.add(0, MENU_ABOUT, 2, "About this application");
	    	// m = mm.add(1, MENU_SYNC,  1, "Upload data");
	    	// m.setIcon(R.drawable.ic_menu_refresh);
	    	//m = mm.add(1, MENU_UPDATE, 1, "Update software");
	    	//m.setIcon(R.drawable.ic_menu_agenda);
	    	return true;
	    }
	    
	    @Override
	    public boolean onOptionsItemSelected(MenuItem item) {
	    	String imei;
	    	switch (item.getItemId())
	    	{
	    		//case MENU_ABOUT: showAboutDialog(); break;
	    		//case MENU_ADMIN: showAdminLoginDialog(); break;
	    		//case MENU_SYNC: doSyncAction(); break;
	    		//case MENU_UPDATE: checkUpdate(); break;
	    		//case MENU_CACHE:
	    		//	WebViewUtil.loadWebView(webview,  this);
	    		//	break;
//	    		case MENU_AUTH:
//	    			imei = DataBaseUtil.getIMEI(self);
//	    	        try {
//	    				webview.loadUrl(setting.getString("webview_url", "http://fangorn.media.mit.edu/dubai/")
//	    						+ MD5.MD5Digest(imei.toUpperCase() + "10") + "/sharing/");
//	    			} catch (NoSuchAlgorithmException e) {
//	    				// TODO Auto-generated catch block
//	    				e.printStackTrace();
//	    			} catch (UnsupportedEncodingException e) {
//	    				// TODO Auto-generated catch block
//	    				e.printStackTrace();
//	    			}
//	    			break;
	    		case MENU_REFRESH: 
	    	        byte[] postdata = loadPDSandToken();
	    	        if (postdata == null) {
	    	        	Log.e(TAG, "pds data not available");
	    	            new AlertDialog.Builder(this)
	    	            .setCancelable(false)
	    	            .setMessage("Your access token is not present. Please check your privacy settings" +
	    	            		"in your Digital Wallet.")
	    	            .show();
	    	        } else {
	    	        	ConnectivityManager cm = (ConnectivityManager) this.getSystemService(Activity.CONNECTIVITY_SERVICE);
	    	        	if ((null == cm.getActiveNetworkInfo()) || (!cm.getActiveNetworkInfo().isConnected()))
	    	        		WebViewUtil.loadWebView(webview, this);
	    	        	else
	    	        		webview.postUrl(VIS_URL, postdata);

		 				loadingText.setVisibility(View.VISIBLE);
		 				//webview.setVisibility(View.GONE);
	    	        }
	    			break;
	    			
	    		
	    	}
	    	return false;
	    }
		
		private byte[] loadPDSandToken() {
			String pds = "";
			String token = "";
			try{
				FileInputStream fi = new FileInputStream("/sdcard/wallet/access_token");
				InputStreamReader isr = new InputStreamReader(fi);
				BufferedReader br = new BufferedReader(isr);
				pds = URLEncoder.encode(br.readLine());
				token = URLEncoder.encode(br.readLine());
				
			} catch (Exception e) {Log.e(TAG, "failed to read pds toekn"); e.printStackTrace(); return null;}
			String httpreq = "pds=" + pds +"&token=" + token;
			Log.i(TAG, httpreq);
			return httpreq.getBytes();
		}
		
}